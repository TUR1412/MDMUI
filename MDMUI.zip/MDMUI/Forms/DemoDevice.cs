using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDMUI.Forms
{
    public partial class DemoDevice : Form
    {
        public DemoDevice()
        {
            InitializeComponent();
        }

        private void DemoDevice_Load(object sender, EventArgs e)
        {
            // 初始化数据等
        }
    }
} 