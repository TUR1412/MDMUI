using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDMUI
{
    public partial class FrmDatabaseBrowser : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=UserDB;Integrated Security=True";
        private SqlConnection connection;
        
        public FrmDatabaseBrowser()
        {
            InitializeComponent();
            
            // 初始化数据库连接
            connection = new SqlConnection(connectionString);
            
            // 加载表格列表
            LoadTables();
        }
        
        private void LoadTables()
        {
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                
                // 获取所有表格
                DataTable tables = connection.GetSchema("Tables");
                lstTables.Items.Clear();
                
                foreach (DataRow row in tables.Rows)
                {
                    string tableName = row["TABLE_NAME"].ToString();
                    lstTables.Items.Add(tableName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载表格列表失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void lstTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstTables.SelectedItem != null)
            {
                string tableName = lstTables.SelectedItem.ToString();
                LoadTableData(tableName);
            }
        }
        
        private void LoadTableData(string tableName)
        {
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                
                string query = $"SELECT * FROM [{tableName}]";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                
                // 显示数据
                dataGridView.DataSource = dataTable;
                
                // 加载表结构
                LoadTableStructure(tableName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载表 {tableName} 数据失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void LoadTableStructure(string tableName)
        {
            try
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                
                string query = $@"
                SELECT 
                    COLUMN_NAME as '列名', 
                    DATA_TYPE as '数据类型',
                    CHARACTER_MAXIMUM_LENGTH as '最大长度',
                    IS_NULLABLE as '允许Null',
                    COLUMN_DEFAULT as '默认值'
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_NAME = '{tableName}'";
                
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable structureTable = new DataTable();
                adapter.Fill(structureTable);
                
                // 显示表结构
                dgvStructure.DataSource = structureTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载表 {tableName} 结构失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void btnExecuteQuery_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtSqlQuery.Text))
                {
                    MessageBox.Show("请输入SQL查询", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                
                SqlDataAdapter adapter = new SqlDataAdapter(txtSqlQuery.Text, connection);
                DataTable resultTable = new DataTable();
                adapter.Fill(resultTable);
                
                // 显示查询结果
                dataGridView.DataSource = resultTable;
                
                tabControl.SelectedIndex = 0; // 切换到数据标签页
            }
            catch (Exception ex)
            {
                MessageBox.Show("执行SQL查询失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            
            // 关闭数据库连接
            if (connection != null && connection.State == ConnectionState.Open)
                connection.Close();
        }
    }
} 